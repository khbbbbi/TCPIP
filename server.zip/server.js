
var express = require('express')
var app = express()
// const path = require('path')
const bodyParser = require('body-parser')

const port = 3000

//session
const session = require('express-session');
const FileStore = require('session-file-store')(session)
app.use(session({
    secret: '~~~',	// 원하는 문자 입력
    resave: true,
    saveUninitialized: true,
    store:new FileStore(),
}))

app.set('view engine','ejs');
app.engine('ejs', require('ejs').__express);
const ejs = require('ejs') //추가

app.use(bodyParser.urlencoded({ extended: false }));
// app.use(express.static('public'));
app.set('view engine', 'ejs');

const mysql = require('mysql');
const { response } = require('express')
const db = mysql.createConnection({
    host: 'localhost',
    port: '3307',
    user: 'root',
    password: '1234',
    database: 'potato',
    multipleStatements: true
});

app.listen(port, () => console.log(`Example app listening on port ${port}!`));

db.connect(function(err) {
    if (err) throw err;
    console.log('Connected');
});

app.get('/', function (req, res) {
    res.render('Login');
})

//로그인
app.post('/logined', function(request, response) {
    var custid = request.body.custid;
    var custpw = request.body.custpw;
    
    if (custid && custpw) {
        db.query('SELECT * FROM customer WHERE custid = ? AND custpw = ?', [custid, custpw], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                request.session.loggedin = true;
                request.session.custid = custid;
                request.session.save(err => {
                    if (err) throw err;
                    response.redirect('/main');
                   // response.render('Mainpage');
                });
                // response.redirect('/main');
                // response.end();
            } else {              
                response.send('<script type="text/javascript">alert("회원 정보가 일치하지 않습니다."); document.location.href="/";</script>');    
            }   
        });
    } else {        
        response.send('<script type="text/javascript">alert("username과 password를 입력하세요!"); document.location.href="/login";</script>');    
        response.end();
    }
});

/////////// 로그아웃
app.get('/logout', function(request, response) {
    request.session.loggedin = false;
    response.send('<script type="text/javascript">alert("성공적으로 로그아웃 되었습니다."); document.location.href="/";</script>');    
    response.end();
});

 //메인화면 내정보
app.get('/main', function(request,response){
    console.log(`${request.session.custid}`);
    //const user = `${request.session.custid}`;
    const custid = request.session.custid
    const sql1 = "select * from customer where custid = ?;";
    const sql2 = "select * from studyroom where custid = ? limit 2;";
    const sql3 = "select * from studyroom limit 6;";
    db.query(sql1 + sql2 + sql3, [custid,custid], function(err, result, fields){
        if(err) throw err;
    //   var sql1_result = results[0];	//sql1 의 결과값
    //   var sql2_result = results[1];	//sql2 의 결과값

        response.render('Mainpage',{myinfo: result[0],mroom: result[1],msroom: result[2]});
        //response.render('Mainpage',{mroom: result[1]});
    });
});


// 게시판 select : Mainpage에서 메뉴바 스터디그룹을 누르면 /GesipanDB가 호출 > 전달할 디비 정보들을 적고 
// res.render로 views폴더에 있는 Gesipan.ejs에 값을 전달하며 페이지 이동
app.get('/Gesipan', function(req,res){
    const custid = req.session.custid
    const sql1 = "select * from  customer where custid = ?;";
    const sql2 = "select * from studyroom";
    db.query(sql1 + sql2, [custid] , function(err, result, fields){
        if(err) throw err;
        res.render('Gesipan', {myinfo: result[0], writing: result[1]});
    });
});
app.post('/Gesipan', function(req,res){
    const custid = req.session.custid
    const sql1 = "select * from  customer where custid = ?;";
    const sql2 = "select * from studyroom";
    db.query(sql1 + sql2, [custid] , function(err, result, fields){
        if(err) throw err;
        res.render('Gesipan', {myinfo: result[0], writing: result[1]});
    });
});

// 위에께 있으면 굳이 이게 필요 없음.
// app.get('/Gesipan', function(req,res){
//     res.sendFile(__dirname + '/Gesipan.html');
// })


// Gesipan.ejs에서 받아온 값 : 방 들어가기 누르면 rooid받아와서 room.ejs에 roomtitle전달
app.get('/goroom/:roomid', (req,res) => {
    const custid = req.session.custid
    const sql1 = "select * from  customer where custid = ?;";
    const sql2 = "select * from studyroom where roomid = ?";
    db.query(sql1+sql2,[custid, req.params.roomid],function (err, result, fields){
        if(err) throw err;
        res.render('room',{myinfo: result[0], room : result[1]});
    });
});


//view>.ejs파일로 이동할땐 요렇게
app.get('/Create', function (req, res) {
    const custid = req.session.custid
    const sql = "select * from  customer where custid = ?;";
    db.query(sql,[custid],function (err, result, fields){
        if(err) throw err;
        res.render('createroom',{myinfo: result});
    });
});

//방만들기 페이지로 이동
app.post('/Create', function (req, res) {
    const custid = req.session.custid
    const sql = "select * from  customer where custid = ?;";
    db.query(sql,[custid],function (err, result, fields){
        if(err) throw err;
        res.render('createroom',{myinfo: result});
    });
});

//createroom -> gesipan : 방 생성
app.post('/gocreate', (req, res) => {
    const sql = "INSERT INTO studyroom SET ?"
    db.query(sql,req.body,function(err, result, fields){
        if(err) throw err;
        res.redirect('/Gesipan')
    });
});


//내가 만든 방 페이지로 값넘김
app.get('/myroom', function(req,res){
    const custid = req.session.custid
    const sql1 = "select * from  customer where custid = ?;";
    const sql2 = "select * from  studyroom where custid = ?;";
    db.query(sql1 + sql2, [custid, custid],function(err, result, fields){
        if(err) throw err;
        res.render('Myroom', {myinfo: result[0],myroom: result[1]});
    });
});